package nusiss.paf.day22revision;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day22RevisionApplicationTests {

	@Test
	void contextLoads() {
	}

}
