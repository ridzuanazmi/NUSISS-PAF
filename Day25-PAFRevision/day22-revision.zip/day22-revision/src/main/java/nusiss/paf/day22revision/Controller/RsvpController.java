package nusiss.paf.day22revision.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import nusiss.paf.day22revision.Model.Rsvp;
import nusiss.paf.day22revision.Service.RsvpService;

@Controller
public class RsvpController {
    
    @Autowired
    RsvpService rsvpSrvc;

    @GetMapping("/rsvps")
    public String getAllRsvp(Model model) {
        List<Rsvp> rsvpList = rsvpSrvc.getAllRsvp();
        model.addAttribute("rsvp", rsvpList);
        return "RsvpList";
    }

    @GetMapping("/rsvps/addNew")
    public String createRsvpForm(Model model) {
        Rsvp rsvpForm = new Rsvp();
        model.addAttribute("rsvp", rsvpForm);
        return "RsvpForm";
    }

    @PostMapping("/rsvps/create")
    public String createRsvp(@ModelAttribute("rsvp") Rsvp rsvpForm, BindingResult result) {

        if (result.hasErrors()) {
            return "RsvpForm";
        }

        Rsvp rsvp = new Rsvp();
        rsvp.setFullName(rsvpForm.getFullName());
        rsvp.setEmail(rsvpForm.getEmail());
        rsvp.setPhone(rsvpForm.getPhone());
        rsvp.setConfirmationDate(rsvpForm.getConfirmationDate());
        rsvp.setComments(rsvpForm.getComments());
        rsvpSrvc.createRsvp2(rsvp);

        return "redirect:/RsvpList";
    }
}
