package nusiss.paf.day22revision;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day22RevisionApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day22RevisionApplication.class, args);
	}

}
